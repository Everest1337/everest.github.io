var tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
var tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate();
var nhour=d.getHours(),nmin=d.getMinutes(),ap;
if(nmin<=9) nmin="0"+nmin

if (am_pm == true){
	if(nhour==0){ap=" AM";nhour=12;}
	else if(nhour<12){ap=" AM";}
	else if(nhour==12){ap=" PM";}
	else if(nhour>12){ap=" PM";nhour-=12;}
	document.getElementById('timebox').innerHTML=""+nhour+":"+nmin+"";
	document.getElementById('ampmbox').innerHTML=""+ap+"";
} else {
	document.getElementById('timebox').innerHTML=""+nhour+":"+nmin+"";
}

if (ordinal_date == true){
	if (ndate == 1) {
		document.getElementById('datebox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+"st"+"";
	} else if (ndate == 2 || ndate == 22) {
		document.getElementById('datebox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+"nd"+"";
	} else if (ndate == 3 || ndate == 23) {
		document.getElementById('datebox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+"rd"+"";
	} else {
		document.getElementById('datebox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+"th"+"";
	}
} else if (daymonth == true) {
	document.getElementById('datebox').innerHTML=""+tday[nday]+", "+ndate+" "+tmonth[nmonth]+"";
} else {
	document.getElementById('datebox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+"";
}

$("html").css("top", clock_height + "px");
$("#timebox").css("font-size", clock_size + "px");
$("#timebox").css("marginBottom", space_between + "px");
$("#datebox").css("font-size", date_size + "px");
 	if (text_shadow == true){
 		$("html").css("text-shadow", "1px 1px 1px #404040");
 	}
	if (enable_mountain == false){
 		document.getElementById("mountain").style.visibility = "hidden";
 	}
	if (enable_clock == false){
 		document.getElementById("timebox").style.visibility = "hidden";
		document.getElementById("ampmbox").style.visibility = "hidden";
 	}
	if (enable_date == false){
 		document.getElementById("datebox").style.visibility = "hidden";
 	}
	
	if (mountain_shadow == true){
		$("img").css("-webkit-filter", "drop-shadow(1px 1px 1px #404040)");
		$("img").css("filter", "drop-shadow(1px 1px 1px #404040)");
	}
}

window.onload=function(){
GetClock();
setInterval(GetClock,1000);
}
